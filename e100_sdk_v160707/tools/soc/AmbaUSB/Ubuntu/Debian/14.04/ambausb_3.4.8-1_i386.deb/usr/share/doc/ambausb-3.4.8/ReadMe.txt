1. Description
AmbaUSB is a utility designed to download firmware to Ambarella's development board;
This is a replacement of DirectUSB.

2. Installation
Unix)
  1. mkdir build
  2. cd build
  3. x86)
     qmake-qt4 ../AmbaUSB.pro -r CONFIG+=release PREFIX=/usr/local ARCH=i686   -spec linux-g++-32
     x86_64)
     qmake-qt4 ../AmbaUSB.pro -r CONFIG+=release PREFIX=/usr/local ARCH=x86_64 -spec linux-g++-64
  4. make
  5. make install
  Note: step 5 needs root privilege;
  You can also use prebuild rpm or deb package.

Windows7 And Above)
  1. mkdir windows
  2. cd windows
  3. x86)
     mingw32-qmake-qt5 ../AmbaUSB.pro -r PREFIX=$(pwd)/AmbaUSB-win32-release ARCH=i686   -spec win32-g++ CONFIG+=release
     x86_64)
     mingw64-qmake-qt5 ../AmbaUSB.pro -r PREFIX=$(pwd)/AmbaUSB-win64-release ARCH=x86_64 -spec win32-g++ CONFIG+=release
  4. make
  5. make install

Windows XP)
  1. mkdir windows
  2. cd windows
  3. x86)
     mingw32-qmake-qt5 ../AmbaUSB.pro -r PREFIX=$(pwd)/AmbaUSB-win32-release ARCH=i686   -spec win32-g++ CONFIG+=release LEGACY=true
     x86_64)
     mingw64-qmake-qt5 ../AmbaUSB.pro -r PREFIX=$(pwd)/AmbaUSB-win64-release ARCH=x86_64 -spec win32-g++ CONFIG+=release LEGACY=true
  4. make
  5. make install

3. Requirements
Unix)
    libusb1, expat and zlib development files are needed to build this software.

Windows)
    This source code can only be built in Linux MinGW development environemnt.
    mingw32 and mingw64 building environemnt in Fedora Linux
    qt-tools qt(Qt version 5) zlib libusbx expat for both mingw32 and mingw64
